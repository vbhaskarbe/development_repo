#!/usr/local/bin/bash 
# Author : Bhaskar Varadaraju
# 
# A Shell program to read user name and greet him.
# Version 1.1

echo "Hello, World!"
echo "Enter your name: "
read name
echo "Hello, $name!"


