#!/usr/local/bin/bash
# Author: Bhaskar Varadaraju
#
# A Shell Program to print 1 to 10 numbers using 'for'
#
for count in {1..10}
do
   echo "$count"
done

